package edu.miu.cs544.util;

public class Constant {
	public static enum ReservationStatus{
		PENDING, CONFIRMED, CANCELLED
	}
	
	public static enum ERole {
	    ROLE_ADMIN,
	    ROLE_AGENT,
	    ROLE_PASSENGER
	}
}
