package edu.miu.cs544.util;

public class Constant {
	public static enum ReservationStatus{
		PENDING, CONFIRMED, CANCELLED
	}
}
