package edu.miu.cs544.controller;

public class TicketController {
	
//	@PatchMapping("/{passengerId}/reservations/{code}/purchase")
//	public List<Ticket> purchaseReservation(@PathVariable Integer passengerId, @PathVariable String code) {
//		return reservationService.purchaseReservation(code, passengerId);
//	}
}
